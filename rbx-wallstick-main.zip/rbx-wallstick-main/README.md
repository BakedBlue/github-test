# rbx-wallstick
A system for sticking characters to surfaces within Roblox.

### Videos

https://github.com/user-attachments/assets/bd4efde2-9323-4db1-896c-6407263e458e

https://github.com/user-attachments/assets/2a0478de-6e1f-4676-b778-9709b9e3f18f

https://github.com/user-attachments/assets/c6d9a53d-f6c2-4924-9286-728e21b92ee8
